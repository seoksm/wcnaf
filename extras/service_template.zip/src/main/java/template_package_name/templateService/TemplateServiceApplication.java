package template_package_name.templateService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(
        scanBasePackages = {
                "template_package_name",
                "com.winitech"
        }
)
@EnableJpaRepositories(basePackages = { 
        "template_package_name.**.infrastructure", 
        "com.winitech.**.infrastructure" 
})
@EntityScan(basePackages = { 
        "template_package_name.**.domain",
        "com.winitech.**.domain" 
})
public class TemplateServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(TemplateServiceApplication.class, args);
    }

}
